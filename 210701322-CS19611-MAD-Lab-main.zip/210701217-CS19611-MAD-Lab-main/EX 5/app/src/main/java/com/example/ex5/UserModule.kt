package com.example.ex5

data class UserModel(val registerNumber: Int, val name: String, val cgpa: Double)